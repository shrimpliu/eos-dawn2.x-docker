/**
 *  @file
 *  @copyright defined in eos/LICENSE.txt
 */
#pragma once
#include <eoslib/types.hpp>
#include <eoslib/message.hpp>
#include <eoslib/print.hpp>
#include <eoslib/math.hpp>
#include <eoslib/transaction.hpp>




