#define BOOST_TEST_MODULE chain
#include <boost/test/included/unit_test.hpp>



