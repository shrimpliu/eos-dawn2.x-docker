/**
 *  @file
 *  @copyright defined in eos/LICENSE.txt
 */
#pragma once

#include <fc/reflect/reflect.hpp>

#include <cstdint>

#include <eos/chain/config.hpp>

namespace eosio { namespace chain {

} } // eosio::chain

