/**
 *  @file
 *  @copyright defined in eos/LICENSE.txt
 */
#include <eos/chain/chain_administration_interface.hpp>

eosio::chain::chain_administration_interface::~chain_administration_interface() {}
