
/**
 *  @file
 *  @copyright defined in eos/LICENSE.txt
 */
namespace memory_test {

} /// namespace memory_test

