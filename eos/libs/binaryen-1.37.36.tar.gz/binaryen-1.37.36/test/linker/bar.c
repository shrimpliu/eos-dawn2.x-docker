void quux();
void bar() { quux(); }
