int puts(const char* str);

int main() {
  puts("Hello, world");
  return 0;
}
