
var Module = {
  asmjsCodeFile: 'a.asm.js' // tell polyfill (which replaces a.asm.js) where the asm.js code is
};

