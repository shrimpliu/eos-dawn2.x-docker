
var Module = {}; // *.asm.js expects this


