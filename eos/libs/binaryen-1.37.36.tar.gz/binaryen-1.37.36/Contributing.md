# Contributing to WebAssembly

Interested in participating? Please follow
[the same contributing guidelines as the design repository][].

  [the same contributing guidelines as the design repository]: https://github.com/WebAssembly/design/blob/master/Contributing.md

Also, please be sure to read [the README.md](README.md) for this repository.
