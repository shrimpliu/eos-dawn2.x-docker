#include <clean-one.h>

#include <stdlib.h>

unsigned int another_method()
{
    unsigned int const size = do_nothing_loop();
    unsigned int const square = size * size;

    return square;
}
