#ifndef CLEAN_ONE_H
#define CLEAN_ONE_H

int do_nothing_loop();

#endif
