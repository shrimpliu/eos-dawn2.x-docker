#include <notexisting.hpp>

int value(int in)
{
    return 2 * in;
}
