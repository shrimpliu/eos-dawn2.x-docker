
#define STR          "nexus"

int zool;
