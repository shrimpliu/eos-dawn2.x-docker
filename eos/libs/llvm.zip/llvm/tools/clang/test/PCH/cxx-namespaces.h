// Header for PCH test cxx-namespaces.cpp

namespace N {
    namespace {
        int x;
    }

    void f();
    void f(int);
}
