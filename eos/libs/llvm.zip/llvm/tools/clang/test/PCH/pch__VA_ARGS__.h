// Header for PCH test fuzzy-pch.c
void f(int X);
