void make_foo(void);
