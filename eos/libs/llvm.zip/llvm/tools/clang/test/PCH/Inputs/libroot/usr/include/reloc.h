#ifndef RELOC_H
#define RELOC_H

#include <reloc2.h>







// Line number 13 below is important
int x = 2;

#endif // RELOC_H
