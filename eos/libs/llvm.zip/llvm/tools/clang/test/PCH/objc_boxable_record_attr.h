// used with objc_boxable.m test
typedef struct __attribute((objc_boxable)) boxable boxable;

