// Header for PCH test multiple_decls.c

struct wide { int value; };
int wide(char);

struct narrow { char narrow; };
char narrow(int);
