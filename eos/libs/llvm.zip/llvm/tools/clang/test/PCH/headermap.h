/* Helper for the headermap.m test */
int x = 17;

