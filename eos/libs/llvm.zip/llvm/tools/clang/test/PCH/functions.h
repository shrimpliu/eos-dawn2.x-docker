/* For use with the functions.c test */




int f0(int x, int y, ...); 
float *f1(float x, float y);

void g0(int *);

void do_abort(int) __attribute__((noreturn));
