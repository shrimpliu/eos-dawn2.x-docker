// Header for PCH test builtins.c
int printf(char const *, ...);
