#line 25 "line-directive.c"
int x;
