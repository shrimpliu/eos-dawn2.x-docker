namespace A {
  int x;
  int y;
}

int foo;
#define foo foo
