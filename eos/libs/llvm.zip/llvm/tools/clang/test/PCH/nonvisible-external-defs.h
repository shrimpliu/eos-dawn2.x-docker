// Helper for PCH test nonvisible-external-defs.h







void f() {
  extern int g(int, int);
}
