#ifdef __cplusplus
extern int i;
#else
extern int j;
#endif
