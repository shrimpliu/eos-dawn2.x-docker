// First header for chain-predecl.m
@class Foo;
@protocol Pro;
