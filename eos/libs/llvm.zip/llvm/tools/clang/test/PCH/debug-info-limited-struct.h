struct foo {
  int i;
};

void func() {
  struct foo *f;
  f->i = 3;
}
