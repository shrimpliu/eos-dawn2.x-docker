#pragma once

struct S {
  int x;
};
