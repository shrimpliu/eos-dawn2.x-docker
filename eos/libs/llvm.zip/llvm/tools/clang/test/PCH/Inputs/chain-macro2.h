#define BARFOO void g();
