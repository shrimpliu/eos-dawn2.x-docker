#define FOOBAR void f();
