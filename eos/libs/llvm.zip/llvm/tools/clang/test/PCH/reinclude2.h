int q1 = A::x;
