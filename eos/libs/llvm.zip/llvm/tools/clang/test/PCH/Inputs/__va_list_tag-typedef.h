// Header for PCH test __va_list_tag-typedef.c

#include <stdarg.h>
typedef va_list va_list_1;
