// used with objc_boxable.m test
struct boxable {
  int dummy;
};

