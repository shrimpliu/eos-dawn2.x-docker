#ifndef RELOC2_H
#define RELOC2_H
#include <stddef.h>









// Line number below is important!
int y = 2;
#endif // RELOC2_H
