// Header for PCH test tentative-defs.c
int variable;






int incomplete_array[];
