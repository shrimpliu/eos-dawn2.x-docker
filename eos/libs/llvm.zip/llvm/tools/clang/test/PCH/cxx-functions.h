void foo() throw( int, short, char, float, double );
