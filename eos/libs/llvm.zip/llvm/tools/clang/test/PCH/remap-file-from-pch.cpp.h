
#define STR "nexus"
