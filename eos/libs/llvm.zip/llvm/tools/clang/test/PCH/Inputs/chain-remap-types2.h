void h(X*);

@interface X (Blah) {
}
@end

void g(X*);

