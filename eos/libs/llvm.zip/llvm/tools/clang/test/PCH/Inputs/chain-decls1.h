void f();

struct one {};
void two();

void many(int i);
struct many;
void many(int j);
struct many;

void noret();
