/* For use with the objc_property.m PCH test */
@interface TestProperties
{
  int value;
  float percentage;
}

+ alloc;

@property int value;
@property float percentage;
@end
