// Header for PCH test __va_list_tag.h

typedef __builtin_va_list va_list;

extern int myvfprintf(const char * , va_list);
