/* Used in enum.c test */

enum Color {
  Red,
  Green,
  Blue
};

enum Shape {
  Square,
  Triangle = 17,
  Rhombus,
  Circle
};

enum Shape aRoundShape = Circle;
