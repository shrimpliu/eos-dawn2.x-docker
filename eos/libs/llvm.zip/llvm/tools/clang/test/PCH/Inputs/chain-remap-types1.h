@class X;

struct Y {
  X *my_X;
};

@interface X {
}
@property X *prop;
@end
